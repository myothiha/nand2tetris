from Parser import Parser


class CodeWriter:
    base_memory_segments = {
        "local": "LCL",
        "argument": "ARG",
        "this": "THIS",
        "that": "THAT",
        "temp": 5
    }

    pointer = ["THIS", "THAT"]

    boolean_commands = {
        "eq": "JEQ",
        "gt": "JGT",
        "lt": "JLT",
    }

    arithmetic_logical_commands = {
        "add": "+",
        "sub": "-",
        "and": "&",
        "or": "|",
    }

    negation_commands = {
        "neg": "-",
        "not": "!"
    }

    label_count = 0

    def __init__(self, sourcefile):
        path = sourcefile.split(".")[0].split("/")
        self.filename = path[-1]
        output_file = sourcefile.split(".")[0] + ".asm"
        self.target = open(output_file, "w")

    def writeArithmetic(self, command):
        output = "// " + command + "\n"
        if command in self.arithmetic_logical_commands:
            output += self.getArithmeticAndLogicalCommand(command)
        elif command in self.negation_commands:
            output += self.getNegationCommand(command)
        elif command in self.boolean_commands:
            output += self.getBooleanCommand(command)
        self.target.write(output)

    def getArithmeticAndLogicalCommand(self, command):
        # D = sp.pop()
        output = self.popStack()

        # num1 = D
        output += "@num1\n"
        output += "M=D\n"

        # D = sp.pop()
        output += self.popStack()

        # D = D (operator) num1
        output += "@num1\n"
        output += "D=D" + self.arithmetic_logical_commands[command] + "M\n"

        # sp.push D
        output += self.pushStack()
        return output

    # For both arithmetic and bitwise: -y and !y
    def getNegationCommand(self, command):
        # D = sp.pop()
        output = self.popStack()

        # D = -D or !D
        output += "D=" + self.negation_commands[command] + "D\n"

        # sp.push D
        output += self.pushStack()
        return output

    def getBooleanCommand(self, command):
        # D = sp.pop()
        output = self.popStack()

        # op = D
        output += "@op\n"
        output += "M=D\n"

        # D = sp.pop()
        output += self.popStack()

        # D = D - op
        output += "@op\n"
        output += "D=D-M\n"

        label_count = str(self.label_count)
        # If D = Op, goto TRUE Label
        output += "@TRUE" + label_count + "\n"
        output += "D;" + self.boolean_commands[command] + "\n"
        # Else, D=0 and goto False Label
        output += "D=0\n"
        output += "@FALSE" + label_count + "\n"
        output += "0;JMP\n"

        # TRUE Body
        output += "(TRUE" + label_count + ")\n"
        output += "D=-1\n"

        # False Body, stack push D
        output += "(FALSE" + label_count + ")\n"
        output += self.pushStack()
        self.label_count += 1
        return output

    def writePushPop(self, command, command_type, segment, index):
        output = "// " + command + "\n"
        if command_type == Parser.C_PUSH:
            if segment == "constant":
                output += self.writePushConstant(index)
            elif segment == "pointer":
                output += self.writePushPointer(index)
            elif segment == "static":
                # D = static i
                output += "@" + self.filename + "." + str(index) + "\n"
                output += "D=M\n"

                # sp.push(D)
                output += self.pushStack()
            else:
                output += self.pushOtherSegments(segment, index)
        elif command_type == Parser.C_POP:
            if segment == "pointer":
                output += self.writePopPointer(index)
            elif segment == "static":
                # D = sp.pop()
                output += self.popStack()

                # static i = D
                output += "@" + self.filename + "." + str(index) + "\n"
                output += "M=D\n"
            else:
                output += self.writePopOtherSegments(segment, index)
        self.target.write(output)

    def close(self):
        self.target.close()

    def writePushConstant(self, index):
        index = str(index)
        # D = index
        output = "@" + index + "\n"
        output += "D=A\n"

        # push D to SP
        output += self.pushStack()
        return output

    def writePushPointer(self, index):
        # D  = THIS/THAT
        output = "@" + self.pointer[index] + "\n"
        output += "D=M\n"

        # push D to stack
        output += self.pushStack()
        return output

    def pushOtherSegments(self, segment, index):
        if segment == "temp":
            # addr = 5 + i
            base_addr = self.base_memory_segments[segment] + index
            output = "@" + str(base_addr) + "\n"
            output += "D=A\n"
        else:
            # D=i
            output = "@" + str(index) + "\n"
            output += "D=A\n"

            # D = segment + i
            output += "@" + self.base_memory_segments[segment] + "\n"
            output += "D=D+M\n"

        # addr = D = segment + i
        output += "@addr\n"
        output += "M=D\n"

        # D= *addr
        output += "@addr\n"
        output += "A=M\n"
        output += "D=M\n"

        # push D to stack
        output += self.pushStack()
        return output

    def writePopPointer(self, index):

        # D= stack.pop
        output = self.popStack()

        # THIS/THAT = D = *SP
        output += "@" + self.pointer[index] + "\n"
        output += "M=D\n"
        return output

    def popStack(self):
        # SP--
        output = "@SP\n"
        output += "M=M-1\n"

        # D = *SP
        output += "@SP\n"
        output += "A=M\n"
        output += "D=M\n"
        return output

    def pushStack(self):
        # push sp D
        output = "@SP\n"
        output += "AM=M+1\n"
        output += "A=A-1\n"
        output += "M=D\n"
        return output

    def writePopOtherSegments(self, segment, index):
        if segment == "temp":
            # addr = 5 + i
            base_addr = self.base_memory_segments[segment] + index
            output = "@" + str(base_addr) + "\n"
            output += "D=A\n"
        else:
            # D=i
            output = "@" + str(index) + "\n"
            output += "D=A\n"
            # D = segment + i
            output += "@" + self.base_memory_segments[segment] + "\n"
            output += "D=D+M\n"

        # addr = D = segment + i
        output += "@addr\n"
        output += "M=D\n"

        # D = stack.pop()
        output += self.popStack()

        # *addr = D = *SP
        output += "@addr\n"
        output += "A=M\n"
        output += "M=D\n"
        return output
