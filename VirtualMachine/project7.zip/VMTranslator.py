import sys
from Parser import Parser
from CodeWriter import CodeWriter


def __main__():
    source_file = sys.argv[1]

    parser = Parser(source_file)
    # source.readline()

    code_writer = CodeWriter(source_file)
    i = 0
    while parser.hasMoreCommands():
        command = parser.advance()
        if parser.commandType() == Parser.C_ARITHMETIC:
            code_writer.writeArithmetic(command)
        else:
            code_writer.writePushPop(command, parser.commandType(), parser.arg1(), parser.arg2())
        i += 1

    code_writer.close()


__main__()
